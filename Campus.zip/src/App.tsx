import { useState } from "react";

type IconName = "home" | "play" | "users" | "network" | "profile" | "heart" | "message" | "send" | "save" | "plus" | "search" | "menu" | "more" | "grid" | "tag" | "chevron" | "arrow" | "pin" | "calendar" | "check" | "moon" | "sun" | "sliders" | "building" | "folder" | "book";

function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  const p: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7"/><path d="M5 9v11h14V9M9 20v-6h6v6"/></>,
    play: <path d="m9 6 9 6-9 6Z"/>,
    users: <><circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M2.5 20v-2.5A4.5 4.5 0 0 1 7 13h2a4.5 4.5 0 0 1 4.5 4.5V20M14 14.5h2.5a4 4 0 0 1 4 4V20"/></>,
    network: <><circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="18" r="2.5"/><circle cx="19" cy="18" r="2.5"/><path d="M12 7.5v4M5 15.5v-2h14v2"/></>,
    profile: <><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>,
    heart: <path d="M20.8 4.8a5.4 5.4 0 0 0-7.7 0L12 5.9l-1.1-1.1a5.4 5.4 0 0 0-7.7 7.7L12 21l8.8-8.5a5.4 5.4 0 0 0 0-7.7Z"/>,
    message: <path d="M21 12a8.5 8.5 0 0 1-9 8.5 10 10 0 0 1-3.8-.8L3 21l1.4-4.7A8.3 8.3 0 0 1 3 12a8.5 8.5 0 0 1 9-8.5 8.5 8.5 0 0 1 9 8.5Z"/>,
    send: <><path d="m22 2-9 20-3.5-8.5L1 10Z"/><path d="M9.5 13.5 22 2"/></>,
    save: <path d="M6 3h12v18l-6-4-6 4Z"/>,
    plus: <path d="M12 5v14M5 12h14"/>,
    search: <><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></>,
    menu: <path d="M4 6h16M4 12h16M4 18h16"/>,
    more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
    grid: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>,
    tag: <><path d="M20 12 12 20l-9-9V3h8Z"/><circle cx="8" cy="8" r="1.5"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    arrow: <><path d="M20 12H4M10 18l-6-6 6-6"/></>,
    pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    moon: <path d="M20.5 15.2A8.5 8.5 0 0 1 8.8 3.5 8.5 8.5 0 1 0 20.5 15.2Z"/>,
    sun: <><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19"/></>,
    sliders: <><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/></>,
    building: <><path d="M4 21V7l8-4 8 4v14M2 21h20"/><path d="M8 10h2M14 10h2M8 14h2M14 14h2M10 21v-3h4v3"/></>,
    folder: <path d="M3 6h7l2 2h9v11H3Z"/>,
    book: <><path d="M4 4h5a3 3 0 0 1 3 3v13a3 3 0 0 0-3-3H4Z"/><path d="M20 4h-5a3 3 0 0 0-3 3v13a3 3 0 0 1 3-3h5Z"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{p[name]}</svg>;
}

const photos = {
  campus: "https://images.unsplash.com/photo-1663162550938-60f70fab5d31?auto=format&fit=crop&w=900&q=85",
  lecture: "https://images.unsplash.com/photo-1758270704763-22072a90d3b6?auto=format&fit=crop&w=900&q=85",
  laptop: "https://images.unsplash.com/photo-1758270705317-3ef6142d306f?auto=format&fit=crop&w=900&q=85",
  study: "https://images.unsplash.com/photo-1760351561007-526f5353cc76?auto=format&fit=crop&w=900&q=85",
  park: "https://images.unsplash.com/photo-1763890763377-abd05301034d?auto=format&fit=crop&w=900&q=85",
  selfie: "https://images.unsplash.com/photo-1758270705555-015de348a48a?auto=format&fit=crop&w=900&q=85",
  tennis: "https://images.unsplash.com/flagged/photo-1576972405668-2d020a01cbfa?auto=format&fit=crop&w=900&q=85",
  racket: "https://images.unsplash.com/photo-1587683437362-da7775ffc532?auto=format&fit=crop&w=900&q=85",
};

const people = [
  ["AP", "Your story"], ["MC", "maya.chen"], ["NS", "noah.s"], ["LE", "lena.evans"], ["TW", "theo.w"], ["SK", "sam.k"], ["IR", "isha.r"],
];

function Avatar({ initials, large = false }: { initials: string; large?: boolean }) {
  return <span className={large ? "avatar avatar-large" : "avatar"}>{initials}</span>;
}

function TopBar({ title, back, onBack, children }: { title: string; back?: boolean; onBack?: () => void; children?: React.ReactNode }) {
  return <header className="topbar"><div className="top-title">{back && <button className="plain" onClick={onBack}><Icon name="arrow" /></button>}<h1>{title}</h1></div><div className="top-actions">{children}</div></header>;
}

function Stories() {
  return <div className="stories">{people.map(([initials, name], i) => <button className="story" key={name}><span className={i === 0 ? "story-ring your-story" : "story-ring"}><Avatar initials={initials} />{i === 0 && <span className="story-plus">+</span>}</span><span>{name}</span></button>)}</div>;
}

function FeedPost({ second = false }: { second?: boolean }) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [slide, setSlide] = useState(0);
  const media = second ? [photos.study] : [photos.laptop, photos.lecture, photos.selfie];
  return <article className="post">
    <div className="post-head"><div className="person-line"><Avatar initials={second ? "LE" : "MC"} /><div><strong>{second ? "lena.evans" : "maya.chen"}</strong><span>{second ? "Main Library" : "Innovation Lab"}</span></div></div><button className="plain"><Icon name="more" /></button></div>
    <div className="post-media" onClick={() => setSlide((slide + 1) % media.length)}>
      <img src={media[slide]} alt={second ? "Students studying together" : "Students collaborating around a laptop"} />
      {media.length > 1 && <><span className="carousel-count">{slide + 1}/{media.length}</span><div className="carousel-dots">{media.map((_, i) => <i className={i === slide ? "active" : ""} key={i} />)}</div></>}
    </div>
    <div className="post-actions"><div><button className={liked ? "plain active-heart" : "plain"} onClick={() => setLiked(!liked)}><Icon name="heart" size={25} /></button><button className="plain"><Icon name="message" size={25} /></button><button className="plain"><Icon name="send" size={25} /></button></div><button className={saved ? "plain saved" : "plain"} onClick={() => setSaved(!saved)}><Icon name="save" size={25} /></button></div>
    <div className="post-copy"><strong>{second ? "89" : "246"} likes</strong><p><strong>{second ? "lena.evans" : "maya.chen"}</strong> {second ? "Midterm season. We have two open seats if anyone wants to join us." : "First working prototype! Swipe through for a peek at today’s build session."}</p><button>View all {second ? "7" : "18"} comments</button><span>2 HOURS AGO</span></div>
  </article>;
}

function Home() {
  return <><TopBar title="Quad"><button className="plain"><Icon name="plus" /></button><button className="plain"><Icon name="heart" /></button><button className="plain"><Icon name="message" /></button></TopBar><main><Stories /><FeedPost /><FeedPost second /></main></>;
}

const experienceData = [
  { title: "Sunset tennis mixer", host: "Campus Racquet Club", date: "Today", time: "6:00–7:30 PM", place: "West Courts", img: photos.tennis, tag: "OFFLINE", joined: 18, capacity: 24 },
  { title: "Portfolio feedback room", host: "Design Collective", date: "Tonight", time: "8:30–9:30 PM", place: "Online", img: photos.laptop, tag: "ONLINE", joined: 31, capacity: 50 },
  { title: "Quiet study social", host: "Peer Learning Network", date: "Tomorrow", time: "4:00–6:00 PM", place: "Main Library", img: photos.study, tag: "OFFLINE", joined: 12, capacity: 20 },
];

function Experiences() {
  return <div className="experiences"><div className="reels-title"><h1>Experiences</h1><button className="plain light"><Icon name="search" /></button></div>{experienceData.map((x, i) => <Experience item={x} key={x.title} index={i} />)}</div>;
}

function Experience({ item, index }: { item: typeof experienceData[number]; index: number }) {
  const [saved, setSaved] = useState(false);
  const [menu, setMenu] = useState(false);
  const [preference, setPreference] = useState<"interested" | "not-interested" | null>(null);
  const [joined, setJoined] = useState(false);
  const [attendeesOpen, setAttendeesOpen] = useState(false);
  const attendeeCount = item.joined + (joined ? 1 : 0);
  const attendees = [
    { initials: "MC", name: "Maya Chen", info: "2nd Year · Product Design" },
    { initials: "NS", name: "Noah Singh", info: "3rd Year · Mechanical Engineering" },
    { initials: "", name: "Hidden", info: "This person has hidden their name" },
    { initials: "LE", name: "Lena Evans", info: "2nd Year · Computer Science" },
  ];
  return <section className="experience">
    <div className="experience-media">
      <img src={item.img} alt={item.title} />
      <div className="experience-title"><span className="event-tag">{item.tag}</span><h2>{item.title}</h2></div>
      <div className="experience-actions">
        <button><Icon name="message" /><span>{8 + index}</span></button>
        <button onClick={() => setSaved(!saved)} className={saved ? "saved" : ""}><Icon name="save" /><span>{saved ? "Saved" : "Save"}</span></button>
        <button onClick={() => setMenu(!menu)} aria-label="Activity preferences"><Icon name="menu" /><span>More</span></button>
        {menu && <div className="preference-menu">
          <button className={preference === "interested" ? "selected" : ""} onClick={() => { setPreference("interested"); setMenu(false); }}>Interested</button>
          <button className={preference === "not-interested" ? "selected" : ""} onClick={() => { setPreference("not-interested"); setMenu(false); }}>Not interested</button>
        </div>}
      </div>
    </div>
    <div className="experience-details">
      <div className="event-meta">
        <div><Icon name="calendar" size={18} /><span><small>WHEN</small><strong>{item.date} · {item.time}</strong></span></div>
        <div><Icon name="pin" size={18} /><span><small>WHERE</small><strong>{item.place}</strong></span></div>
      </div>
      <div className="attendance">
        <button onClick={() => setAttendeesOpen(true)}><strong>{attendeeCount}</strong><span>joined · view</span></button>
        <div><strong>{item.capacity - attendeeCount}</strong><span>spots left</span></div>
        <div><strong>{item.capacity}</strong><span>capacity</span></div>
      </div>
      <div className="map-card">
        <div className="map-road road-one" /><div className="map-road road-two" /><div className="map-road road-three" />
        <span className="map-pin"><Icon name="pin" size={20} /></span>
        <small>{item.place}</small>
      </div>
      <div className="posted-by"><span>Posted by <strong>{item.host}</strong></span>{preference && <span className="preference-status">{preference === "interested" ? "Interested" : "Not interested"}</span>}</div>
      <button className={joined ? "experience-join joined" : "experience-join"} onClick={() => setJoined(!joined)}>{joined ? <><Icon name="check" size={17} /> Joined</> : "Join experience"}</button>
    </div>
    {attendeesOpen && <div className="attendee-sheet">
      <div className="attendee-head"><div><h3>People joining</h3><span>{attendeeCount} attendees</span></div><button onClick={() => setAttendeesOpen(false)}>Done</button></div>
      <div className="attendee-list">
        {joined && <div className="attendee-row"><Avatar initials="AP" /><div><strong>Alex Parker</strong><span>You</span></div></div>}
        {attendees.map(person => <div className="attendee-row" key={person.name + person.info}>
          {person.initials ? <Avatar initials={person.initials} /> : <span className="hidden-avatar"><Icon name="profile" size={19} /></span>}
          <div><strong>{person.name}</strong><span>{person.info}</span></div>
        </div>)}
        {attendeeCount > attendees.length + (joined ? 1 : 0) && <p className="more-attendees">And {attendeeCount - attendees.length - (joined ? 1 : 0)} more people</p>}
      </div>
    </div>}
  </section>;
}

const clubs = [
  ["Robotics Club", "Build, compete, and learn together.", "284 members", "RC", photos.laptop, true],
  ["Design Collective", "Critiques, workshops, and studio visits.", "192 members", "DC", photos.lecture, true],
  ["Campus Runners", "Social runs for every pace.", "341 members", "CR", photos.campus, false],
  ["Debate Society", "Think clearly. Speak confidently.", "156 members", "DS", photos.selfie, false],
  ["Tennis Club", "Weekly play and campus tournaments.", "227 members", "TC", photos.tennis, true],
];

function Communities() {
  const [filter, setFilter] = useState<"For you" | "All" | "Joined">("For you");
  const [joined, setJoined] = useState<string[]>([]);
  const visible = clubs.filter((c) => filter === "All" || filter === "Joined" ? filter === "All" || joined.includes(c[0] as string) : c[5]);
  return <><TopBar title="Communities"><button className="plain"><Icon name="search" /></button></TopBar><main className="page">
    <div className="filters"><Icon name="sliders" size={18} />{(["For you", "All", "Joined"] as const).map(x => <button className={filter === x ? "filter active" : "filter"} onClick={() => setFilter(x)} key={x}>{x}</button>)}</div>
    <h2 className="page-heading">{filter === "For you" ? "Based on your interests" : filter === "Joined" ? "Your communities" : "Explore communities"}</h2>
    <div className="club-list">{visible.length ? visible.map(c => <article className="club-card" key={c[0] as string}><img src={c[4] as string} alt="" /><div className="club-body"><div className="club-avatar">{c[3]}</div><h3>{c[0]}</h3><p>{c[1]}</p><span>{c[2]}</span><button className={joined.includes(c[0] as string) ? "join joined" : "join"} onClick={() => setJoined(joined.includes(c[0] as string) ? joined.filter(j => j !== c[0]) : [...joined, c[0] as string])}>{joined.includes(c[0] as string) ? <><Icon name="check" size={16} /> Joined</> : "Join"}</button></div></article>) : <div className="empty"><Icon name="users" size={34} /><h3>No joined communities yet</h3><p>Explore communities and join the ones you like.</p></div>}</div>
  </main></>;
}

const classmates = [
  ["MC", "Maya Chen", "Product Design", photos.selfie], ["NS", "Noah Singh", "Robotics", photos.lecture],
  ["LE", "Lena Evans", "UX Research", photos.study], ["TW", "Theo Wright", "Physical Computing", photos.laptop],
  ["SK", "Sam Kim", "Visual Design", photos.park], ["IR", "Isha Rao", "Interaction Design", photos.campus],
];

function Network() {
  const [directory, setDirectory] = useState(false);
  const [trail, setTrail] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [skill, setSkill] = useState("All");
  const [connected, setConnected] = useState<string[]>([]);
  const level = trail.length;
  const titles = ["Find your class", "Choose a year", "Choose your stream", "Choose your class", "Classmates"];
  const options = level === 0 ? ["Northbridge College", "City Arts Institute", "Westfield University", "National Tech University"] : level === 1 ? ["1st Year", "2nd Year", "3rd Year", "4th Year"] : level === 2 ? ["Product Design", "Computer Science", "Electronics", "Business"] : ["Section A", "Section B", "Section C"];
  const suggestions = [
    { name: "Maya Chen", initials: "MC", info: "2nd Year · Product Design", skills: ["Product Design", "Startups"], image: photos.selfie, mutual: "12 mutual connections" },
    { name: "Noah Singh", initials: "NS", info: "3rd Year · Mechanical Engineering", skills: ["Robotics", "Startups"], image: photos.lecture, mutual: "8 mutual connections" },
    { name: "Lena Evans", initials: "LE", info: "2nd Year · Computer Science", skills: ["Product Design", "Coding"], image: photos.study, mutual: "5 mutual connections" },
    { name: "Theo Wright", initials: "TW", info: "4th Year · Electrical Engineering", skills: ["Robotics", "Electronics"], image: photos.laptop, mutual: "3 mutual connections" },
    { name: "Sam Kim", initials: "SK", info: "1st Year · Business", skills: ["Tennis", "Startups"], image: photos.park, mutual: "9 mutual connections" },
    { name: "Isha Rao", initials: "IR", info: "2nd Year · Visual Design", skills: ["Product Design", "Photography"], image: photos.campus, mutual: "6 mutual connections" },
  ];
  const visiblePeople = suggestions.filter(person => {
    const matchesQuery = `${person.name} ${person.info} ${person.skills.join(" ")}`.toLowerCase().includes(query.toLowerCase());
    return matchesQuery && (skill === "All" || person.skills.includes(skill));
  });
  if (!directory) return <><TopBar title="Network"><button className="directory-button" onClick={() => setDirectory(true)} aria-label="Browse university directory"><Icon name="building" size={20} /></button></TopBar><main className="page discover-network">
    <div className="network-search"><Icon name="search" size={18} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search people, skills or interests" /></div>
    <div className="skill-filters">{["All", "Product Design", "Robotics", "Tennis", "Startups"].map(item => <button className={skill === item ? "active" : ""} onClick={() => setSkill(item)} key={item}>{item}</button>)}</div>
    <div className="discover-heading"><div><h2>People you may like</h2><span>Based on your interests and connections</span></div><Icon name="sliders" size={19} /></div>
    <div className="suggestion-list">{visiblePeople.map(person => <article className="suggestion-card" key={person.name}>
      <img src={person.image} alt={`${person.name} profile`} />
      <div className="suggestion-info"><strong>{person.name}</strong><span>{person.info}</span><small>{person.mutual}</small><div>{person.skills.map(item => <i key={item}>{item}</i>)}</div></div>
      <button className={connected.includes(person.name) ? "connect connected" : "connect"} onClick={() => setConnected(connected.includes(person.name) ? connected.filter(name => name !== person.name) : [...connected, person.name])}>{connected.includes(person.name) ? <><Icon name="check" size={15} /> Connected</> : "Connect"}</button>
    </article>)}</div>
    {!visiblePeople.length && <div className="empty"><Icon name="search" size={32} /><h3>No people found</h3><p>Try another skill, interest, or name.</p></div>}
  </main></>;
  return <><TopBar title={titles[level]} back onBack={() => level > 0 ? setTrail(trail.slice(0, -1)) : setDirectory(false)}><span className="directory-indicator"><Icon name="building" size={18} /></span></TopBar><main className="page network-page">
    {level > 0 && <div className="breadcrumb"><span>{trail.join("  /  ")}</span></div>}
    {level < 4 ? <><div className="network-intro"><span className="step">STEP {level + 1} OF 4</span><h2>{["Select your institution", "What year are you in?", "Select your course or stream", "Which class are you in?"][level]}</h2><p>This helps us show the right people. You can browse any public college and class.</p></div><div className="folder-list">{options.map((x, i) => <button onClick={() => setTrail([...trail, x])} key={x}><span className="folder-icon"><Icon name={level === 0 ? "building" : level === 1 ? "book" : "folder"} /></span><span><strong>{x}</strong><small>{level === 0 ? `${1200 - i * 183} students` : level === 3 ? `${38 - i * 4} classmates` : `${4 + i} groups`}</small></span><Icon name="chevron" size={18} /></button>)}</div></> :
    <><div className="class-summary"><div><span className="live-dot" /> 24 active this week</div><p>Second Year · Product Design · Section A</p></div><div className="class-grid">{classmates.map(c => <article key={c[1]}><img src={c[3]} alt={`${c[1]} profile`} /><div><strong>{c[1]}</strong><span>{c[2]}</span><button>Connect</button></div></article>)}</div></>}
  </main></>;
}

function Profile({ dark, toggleTheme }: { dark: boolean; toggleTheme: () => void }) {
  const [settings, setSettings] = useState(false);
  const [profileTab, setProfileTab] = useState<"posts" | "projects" | "communities">("posts");
  return <><TopBar title="alex.parker"><button className="plain" onClick={() => setSettings(!settings)}><Icon name="menu" /></button></TopBar><main className="profile-page">
    {settings && <section className="settings-panel"><h3>Settings</h3><button onClick={toggleTheme}><span><Icon name={dark ? "moon" : "sun"} size={20} />Dark mode</span><i className={dark ? "toggle on" : "toggle"}><b /></i></button></section>}
    <section className="profile-summary">
      <div className="profile-overview">
        <Avatar initials="AP" large />
        <div className="profile-bio">
          <h2>Alex Parker</h2>
          <span>Product Designer · 2nd Year</span>
          <p>I like making useful things with thoughtful people. Currently exploring accessible technology and physical computing.</p>
        </div>
      </div>
      <div className="bio-groups">
        <div><strong>Interests</strong><span>Robotics</span><span>Tennis</span><span>Startups</span><span>Accessibility</span></div>
        <div><strong>Skills</strong><span>Product Design</span><span>Prototyping</span><span>UX Research</span><span>Figma</span></div>
      </div>
    </section>
    <div className="profile-tabs">
      <button className={profileTab === "posts" ? "active" : ""} onClick={() => setProfileTab("posts")} aria-label="Posts"><Icon name="grid" /></button>
      <button className={profileTab === "projects" ? "active" : ""} onClick={() => setProfileTab("projects")} aria-label="Projects"><Icon name="message" /></button>
      <button className={profileTab === "communities" ? "active" : ""} onClick={() => setProfileTab("communities")} aria-label="Communities"><Icon name="users" /></button>
    </div>
    {profileTab === "posts" && <div className="photo-grid">{[photos.laptop, photos.tennis, photos.study, photos.lecture, photos.racket, photos.selfie, photos.campus, photos.park, photos.laptop].map((src, i) => <img src={src} alt={`Alex's post ${i + 1}`} key={i} />)}</div>}
    {profileTab === "projects" && <ProjectChats />}
    {profileTab === "communities" && <ProfileCommunities />}
  </main></>;
}

function ProjectChats() {
  const projects = [
    { initials: "CN", name: "Campus Navigator", sender: "Maya", update: "I uploaded the revised route prototype.", time: "10:42 AM", unread: 3 },
    { initials: "SC", name: "Solar Car Dashboard", sender: "Noah", update: "The sensor test results are in the drive.", time: "9:18 AM", unread: 1 },
    { initials: "AC", name: "Accessible Campus", sender: "You", update: "Let’s review the interview notes tomorrow.", time: "Yesterday", unread: 0 },
    { initials: "SD", name: "Studio Directory", sender: "Lena", update: "New update: search and filters are ready.", time: "Monday", unread: 0 },
  ];
  return <section className="project-chats">
    <div className="chat-section-head"><div><h3>Projects</h3></div><button aria-label="Start a project"><Icon name="plus" size={19} /></button></div>
    {projects.map(project => <button className="chat-row" key={project.name}>
      <span className="chat-avatar">{project.initials}</span>
      <span className="chat-content"><span className="chat-name"><strong>{project.name}</strong><time>{project.time}</time></span><span className="chat-preview"><span><strong>{project.sender}:</strong> {project.update}</span>{project.unread > 0 && <i>{project.unread}</i>}</span></span>
    </button>)}
  </section>;
}

function ProfileCommunities() {
  const joined = [
    { initials: "DC", name: "Design Collective", members: "192 members", image: photos.lecture },
    { initials: "RC", name: "Robotics Club", members: "284 members", image: photos.laptop },
    { initials: "TC", name: "Tennis Club", members: "227 members", image: photos.tennis },
    { initials: "PL", name: "Peer Learning", members: "156 members", image: photos.study },
  ];
  return <section className="profile-communities">
    <div className="chat-section-head"><div><h3>Communities</h3><span>{joined.length} joined</span></div></div>
    <div className="joined-grid">{joined.map(group => <article key={group.name}><img src={group.image} alt="" /><div><span className="joined-avatar">{group.initials}</span><strong>{group.name}</strong><small>{group.members}</small><button>View</button></div></article>)}</div>
  </section>;
}

const tabs: { label: string; icon: IconName }[] = [
  { label: "Home", icon: "home" }, { label: "Experiences", icon: "play" }, { label: "Communities", icon: "users" }, { label: "Network", icon: "network" }, { label: "Profile", icon: "profile" },
];

export default function App() {
  const [tab, setTab] = useState(0);
  const [dark, setDark] = useState(false);
  const pages = [<Home />, <Experiences />, <Communities />, <Network />, <Profile dark={dark} toggleTheme={() => setDark(!dark)} />];
  return <div className={dark ? "app dark" : "app"}><div className="phone"><div className="screen">{pages[tab]}</div><nav className="tabbar">{tabs.map((t, i) => <button className={i === tab ? "active" : ""} onClick={() => setTab(i)} key={t.label}><Icon name={t.icon} size={22} /><span>{t.label}</span></button>)}</nav></div></div>;
}
